
//const c = requires("circle");

var circle = require("./caltest.js");
var rec = require("./caltest.js");
var cyl = require("./caltest.js");
//import circle from './caltest.js';

//circle.circle(prompt("Enter Radius"));

var c= new circle(prompt("Enter Radius"));
console.log('------------');
console.log('Radius =',c.radius);
console.log('Area of Circle Is =', c.area().toFixed(2));



var r = new rec(prompt("Enter Length"),prompt("Enter Width"));
console.log('------------');
console.log('Length =',r.length);
console.log('Width =',r.width);
console.log('Area Of Rectangle Is =', r.area().toFixed(2));
console.log('------------');


var cy = new cyl(prompt("Enter Radius"),prompt("Enter Height"));
console.log('Radius =',cy.rad);
console.log('Height =',cy.height);
console.log('Surface Area Of Cylinder Is =', cy.area().toFixed(2));
console.log('------------');
