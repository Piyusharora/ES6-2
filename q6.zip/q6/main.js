        
        let a=[1,2,2,4,5];
        let b= Array.from(new Set(a));
        module.exports=a;
        module.exports=b;