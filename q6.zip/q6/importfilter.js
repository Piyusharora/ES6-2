
        var c= require("./caltest.js");
        
         //import {a,b} from './main.js';
         
         console.log(b);
        
